import java.io.File;
import java.io.IOException;

public class AA1 
{

	public static void main(String[] args) throws IOException
	{
		File f1=new File("D://pankaj1");
		System.out.println(f1.mkdir());
		
		File f2=new File(f1, "pankaj.txt");
		System.out.println(f2.createNewFile());
		System.out.println("done");

	}

}
