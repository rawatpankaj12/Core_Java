//CREATING A FILE FOR STUDENT REGISTRATION

import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class Student 
{

	public static void main(String[] args) throws IOException
	{
		Scanner in =new Scanner(System.in);
		FileWriter out =new FileWriter("student.txt");
		System.out.println("ENTER THE NUMBER OF STUDENTS");
		int n=in.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println("Student NO:"+i);
			out.write("Student NO"+i);
			System.out.println("ENTER THE ROLL NO");
			int roll_no=in.nextInt();
			out.write("\nROLL NO:\n"+roll_no);
			System.out.println("ENTER THE NAME");
			String name=in.next();
			out.write("\n Name:\n"+name);
			out.write("\n........................................\n");
			}
		out.flush();
		out.close();
		System.out.println("YOUR REGISTRATION IS DONE");

	}

}
