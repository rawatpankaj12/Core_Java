//WRITNG A FILE

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class B 
{

	public static void main(String[] args) throws IOException 
	{
		File f1=new File("test11.txt");
		FileWriter out=new FileWriter(f1);
		out.write("\n My name is Pankaj Singh rawat\n");
		out.write("\n My first java class\n");
		out.write("Thank You");
		out.flush();
		out.close();
		System.out.println("Done");
	}

}
