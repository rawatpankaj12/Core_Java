//READING A FILE

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class C 
{

	public static void main(String[] args) throws IOException
	{
		try
		{
			File f1=new File("test11.txt");
			FileReader fr=new FileReader(f1);
			long len=f1.length();
			System.out.println(len);
			char x[]=new char[(int)len];
			fr.read();
			fr.close();
			}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}

	}

}
