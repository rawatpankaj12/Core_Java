package multithreading;

public class G implements Runnable
{
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println("New thread");
		}
	}

	public static void main(String[] args)
	{
	G g1=new G();
	Thread t1=new Thread(g1);
	t1.start();
	for(int i=10;i<20;i++)
	{
		System.out.println("Main thread");
	}
	}

}
