package multithreading;

public class C extends Thread
{
public void run()
{
	for(int i=0;i<2000;i++)
	{
		System.out.println(i);
	}
	}
	public static void main(String[] args) throws InterruptedException
	{
		B b1=new B();
		b1.setDaemon(true);
		b1.start();
		b1.join();
		for(int i=10;i<20;i++)
		{
			System.out.println(i);
		}
		

	}

}
