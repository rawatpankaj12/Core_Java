package multithreading;

public class A extends Thread
{
public void run()
{
	for(int i=0;i<2000;i++)
	{
		System.out.println("New Thread"+i);
	}
	}
	public static void main(String[] args)
	{
	A a1=new A();
	a1.start();
	for(int i=2000;i<4000;i++)
	{
		System.out.println("Main Thread"+i);
	}

	}

}
