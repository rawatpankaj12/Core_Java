package multithreading;

//Program that execute for 5 minutes and after that program should terminate!!!
public class E 
{
	public void run()
	{
		for(int i=0;i<10;i++)
			System.out.println(i);
	}

	public static void main(String[] args) throws InterruptedException
	{
		E e1=new E();
		e1.start();
		for(int i=10;i<20;i++)
		{
			Thread.sleep(300000);
			System.out.println(i);
		}
		System.exit(0);

	}

	private void start() 
	{
				
	}

}
