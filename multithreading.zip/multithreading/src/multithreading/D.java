package multithreading;

public class D 
{
public void run()
{
	for(int i=0;i<600;i++)
	{
		System.out.println(i);
	}
		}
	public static void main(String[] args) throws InterruptedException 
	{
		D d1=new D();
		d1.start();
		for(int i=10;i<700;i++)
		{
			Thread.sleep(2000);
			System.out.println(i);
		}

	}
	private void start() 
	{
		
		
	}

}
