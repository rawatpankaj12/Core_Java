package set;

import java.util.HashSet;

public class A 
{

	public static void main(String[] args) 
	{
		HashSet set=new HashSet();
		set.add(21);
		set.add(34);
		set.add(43.45);
		set.add(21);
		set.add("abc");
		set.add(true);
System.out.println(set);
	}

}
