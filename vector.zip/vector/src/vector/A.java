package vector;

import java.util.Vector;

public class A 
{

	public static void main(String[] args)
	{
		Vector list=new Vector();
		list.add(123);
		list.add(23);
		list.add("abd");
		list.add('c');
		list.add(789.90);
		System.out.println(list);

	}

}
