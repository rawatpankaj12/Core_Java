package vector;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class Manager1
{

	public static void main(String[] args)
	{
		Vector v1=new Vector();
		
		v1.add(90);
		v1.add("abc");
		v1.add(56);
		v1.add(90);
		
		System.out.println(v1);
		//Iterator i1= v1.iterator();
		Enumeration e1=v1.elements();
		while(e1.hasMoreElements())
		{
			System.out.println(e1.nextElement()+" ");
		}
			
		

	}

}
