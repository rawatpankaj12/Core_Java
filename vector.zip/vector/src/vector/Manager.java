package vector;

import java.util.LinkedList;
import java.util.Vector;

public class Manager 
{

	public static void main(String[] args)
	{
		Vector v1=new Vector();
		v1.add(" ");
		v1.add(142);
		v1.add(56);
		v1.add(78);
		v1.add(45);
		v1.add(49);
		v1.add(" ");
		
		System.out.println(v1);
		Object o1=v1.removeFirst();
		System.out.println(o1);
		Object o2=v1.removeLast();
		System.out.println(o2);
		
		

	}

}
