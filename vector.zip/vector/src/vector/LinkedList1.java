package vector;

import java.util.LinkedList;

public class LinkedList1 
{

	public static void main(String[] args)
	{
		LinkedList list=new LinkedList();
		list.add(123);
		list.add(67);
		list.add(56);
		list.add(89);
		list.add(63);
		
		System.out.println(list);
		System.out.println(list.poll());
		System.out.println(list);
		
		System.out.println(list.peek());
		System.out.println(list);
		

	}

}
